    </div>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://unpkg.com/ionicons@4.4.8/dist/ionicons.js"></script>

        <script src="assets/js/panel.js" ></script>
        <!-- <script src="assets/js/script.js"></script> -->
    </body>
    
</html>